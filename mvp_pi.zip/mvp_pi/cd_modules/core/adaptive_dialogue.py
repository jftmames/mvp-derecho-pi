class AdaptiveDialogue:
    """TODO: implementar"""